var main = function() {
    var state;
    
    //C button :D
    $('#note-c').click(function() {
        $('#c').trigger("play");
    });
    //C# button :D
    $('#note-c#').click(function() {
        $('#c_sharp').trigger("play");
    });
    //D button :D
    $('#note-d').click(function() {
        $('#d').trigger("play");
    });
    //D# button :D
    $('#note-d#').click(function() {
        $('#d_sharp').trigger("play");
    });
    //E button :D
    $('#note-e').click(function() {
        $('#e').trigger("play");
    });
    //F button :D
    $('#note-f').click(function() {
        $('#f').trigger("play");
    });
    //F# button :D
    $('#note-f#').click(function() {
        $('#f_sharp').trigger("play");
    });
    //G button :D
    $('#note-g').click(function() {
        $('#g').trigger("play");
    });
    //G# button :D
    $('#note-g#').click(function() {
        $('#g_sharp').trigger("play");
    });
    //A button :D
    $('#note-a').click(function() {
        $('#a').trigger("play");
    });
    //A#button :D
    $('#note-a#').click(function() {
        $('#a_sharp').trigger("play");
    });
    //B button :D
    $('#note-b').click(function() {
        $('#b').trigger("play");
    });
}
$(document).ready(main);